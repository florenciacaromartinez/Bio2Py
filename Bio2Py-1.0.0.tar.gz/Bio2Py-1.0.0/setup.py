from setuptools import setup, find_packages

setup(
    name='Bio2Py',  
    version='1.0.0',            
    description='Library with routines to run BioWin simulations using Python',
    #url='',
    author='Florencia Caro',
    author_email='fcaro@fing.com',

    packages=find_packages(include=['Bio2Py']),
    package_data={'Bio2Py': ['images/*']},
    install_requires=[
        'numpy>=1.26.1',
        'opencv-python>=4.8.1.78',
        'pandas>=2.1.1',
        'psutil>=5.9.5',
        'pyautogui>=0.9.54',
        'pyperclip>=1.8.2',
        'pyrect>=0.2.0',
    ],
    
    #license='',
    python_requires='>=3.12',
    include_package_data=True,
)
