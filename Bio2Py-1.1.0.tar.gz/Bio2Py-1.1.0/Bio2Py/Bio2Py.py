"""
@author Florencia Caro
"""
import pyautogui
import logging
import time
import pyperclip
import psutil
import pandas as pd 
import os
import pkg_resources
import winreg


logging.basicConfig(level=logging.INFO, format='%(asctime)s.%(msecs)03d: %(message)s', datefmt='%H:%M:%S')

simulation_window=();
influent_window=();

def imPath(image_name): 
    """
    A shortcut for joining the 'images/'' file path. 
    
    Args:
        - image_name (str): name of the image to be read. 
  
    Returns: 
    Filename with 'images/' prepended.
    """
  
    image_path = pkg_resources.resource_filename('Bio2Py', f'images/{image_name}') 

    
    return image_path 

#1.Open simulation file
def open_file_with_keyboard(file_path):
    """
    Open BioWin simulation.
    
    Args:
        - file_path: BioWin simulation file path. Use the form: r"path".
    """
    try:
        pyautogui.press('winleft') #Open Windows Start menu (Windows key) 
        time.sleep(1)
        pyperclip.copy(file_path)  
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1)
        pyautogui.press('enter')
        print(f"Opening file: {file_path}")
    except Exception as e:
        print(f"Error opening file: {e}")

#2. Find BioWin window
def locate_biowin():
    """
    Locate BioWin window.
    """
    try:
        pyautogui.click(pyautogui.locateCenterOnScreen(imPath('locatebiowin_2.PNG'),confidence=0.7, grayscale=True))
    except pyautogui.ImageNotFoundException:
        try:
            pyautogui.click(pyautogui.locateCenterOnScreen(imPath('locatebiowin.png'),confidence=0.7, grayscale=True))
        except pyautogui.ImageNotFoundException:
            return 'Image not found'


#3. Set the environment 
def regions_simulation_window():
    """
    Locate and save the region of the program's windows.
    """
    #Simulation window
    pyautogui.press('f5')
    time.sleep(2)
    try:
        top_left_sim_act=pyautogui.locateOnScreen(imPath('locate_simulation_window_2.PNG'),confidence=0.8,grayscale=True)
        bottom_right_sim=pyautogui.locateOnScreen(imPath('locate_simulation_window2_2.PNG'),confidence=0.85, grayscale=True)
        sim_window=(top_left_sim_act[0],top_left_sim_act[1],bottom_right_sim[1]-top_left_sim_act[1],bottom_right_sim[0]-top_left_sim_act[0]+10)
        select=pyautogui.locateOnScreen(imPath('stop_2.PNG'),confidence=0.8,region=sim_window)
        pyautogui.click(select)
        time.sleep(1)
        pyautogui.press('enter')
        time.sleep(1)
    except pyautogui.ImageNotFoundException:
        try:
            top_left_sim_act=pyautogui.locateOnScreen(imPath('locate_simulation_window.png'),confidence=0.8,grayscale=True)
            bottom_right_sim=pyautogui.locateOnScreen(imPath('locate_simulation_window2.png'),confidence=0.8, grayscale=True)
            sim_window=(top_left_sim_act[0],top_left_sim_act[1],bottom_right_sim[1]-top_left_sim_act[1],bottom_right_sim[0]-top_left_sim_act[0]+10)
            select=pyautogui.locateOnScreen(imPath('stop.png'),confidence=0.8,region=sim_window)
            pyautogui.click(select)
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(1)
        except pyautogui.ImageNotFoundException:
            return 'Image not found'
    return sim_window

def regions_influent_window():
    #Load influent window
    try:
        select=pyautogui.locateCenterOnScreen(imPath('infc_load_2.png'), confidence=0.7,grayscale=True) 
        pyautogui.doubleClick(select)
        time.sleep(2)
        top_left=pyautogui.locateOnScreen(imPath('locateediting_inf_2.png'),confidence=0.9,grayscale=True)
        inf_window=(top_left[0],top_left[1],top_left[0]+200,top_left[0]+200)
        pyautogui.press('esc')
        time.sleep(0.5)
        locate_biowin()
    except pyautogui.ImageNotFoundException:
        try:
            select=pyautogui.locateCenterOnScreen(imPath('infc_load.png'), confidence=0.7,grayscale=True) 
            pyautogui.doubleClick(select)
            time.sleep(2)
            top_left=pyautogui.locateOnScreen(imPath('locateediting_inf.png'),confidence=0.9,grayscale=True)
            inf_window=(top_left[0],top_left[1],top_left[0]+200,top_left[0]+200)
            pyautogui.press('esc')
            time.sleep(0.5)
            locate_biowin()
        except pyautogui.ImageNotFoundException:
            return 'Image not found'

    return inf_window

def maximize ():
    """
    Maximize BioWin window. 
    """
    try:
        select=pyautogui.locateCenterOnScreen(imPath('maxmin_2.png'),confidence=0.8,grayscale=True)
    except pyautogui.ImageNotFoundException:
        try:
            select=pyautogui.locateCenterOnScreen(imPath('maxmin.png'),confidence=0.8,grayscale=True)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('maxmin_3.png'),confidence=0.8,grayscale=True)
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
    
    pyautogui.rightClick(select)
    time.sleep(0.5)
    pyautogui.press('down')
    pyautogui.press('down')
    pyautogui.press('down')
    pyautogui.press('down')
    pyautogui.press('down')
    pyautogui.press('enter')

def minimize ():
    """
    Minimize BioWin window. 
    """
    try:
        select=pyautogui.locateCenterOnScreen(imPath('maxmin_2.png'),confidence=0.8,grayscale=True)
    except pyautogui.ImageNotFoundException:
        try:
            select=pyautogui.locateCenterOnScreen(imPath('maxmin.png'),confidence=0.8,grayscale=True)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('maxmin_3.png'),confidence=0.8,grayscale=True)
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
    
    pyautogui.rightClick(select)
    time.sleep(0.5)
    pyautogui.press('down')
    pyautogui.press('enter')
    

def setting_the_environment():
    """
    Locates and saves the region of the program's windows.
    """
    maximize()
    time.sleep(0.5)
    simulation_window=regions_simulation_window()
    influent_window=regions_influent_window()
    time.sleep(0.5)
    minimize()
    return simulation_window, influent_window

    

#4. Check cpu
def check_cpu_usage(program_name, threshold, max_time):
    """
    Checks if CPU usage percentage of a program is below a given threshold in a set period.
    
    Args:
        - program_name (str): Name of the program to be checked.
        - threshold (float): Threshold to compare with the CPU usage percentage.
        - max_time (int): Maximum execution time (in seconds).
    
    Returns:
        - bool: True if CPU percentage is below the threshold, False if the maximum time is reached.
    """
    start_time = time.time()
    def cpu_usage_below_threshold(program_name, threshold):
        """
        Checks if CPU usage percentage of a program is below a given threshold at the time.
        
        Args:
            - program_name (str): Name of the program to be checked.
            - threshold (float): Threshold to compare with the CPU usage percentage.

        Returns:
            - bool: True if the CPU percentage is below the threshold. 
        """
        for process in psutil.process_iter(['name', 'cpu_percent']):
            if program_name.lower() in process.info['name'].lower():
                cpu_percent = process.info['cpu_percent']
                return cpu_percent < threshold
        return 'Program not found'
    
    while True:
        result = cpu_usage_below_threshold(program_name, threshold)
        if result:
            return True  # If the result is True, exit the loop

        current_time = time.time()
        if current_time - start_time > max_time:
            return False  # If more time than the maximum allowed has passed, exit the loop

        time.sleep(1)  # Wait 1 second before the next iteration

#5. Choose simulation seed value
def start_from(option):
    """
    Chose simulation seed values. BioWin has 4 options: seed, current values, last steady state and complex seed. 
    
    Args:
        - option(str): 'seed' (seed), 'current' (current values), 'last' (last steady state), 'complex' (complex seed). 
    """
    if option=='seed':
        try:
            select=pyautogui.locateCenterOnScreen(imPath('seed_2.png'),confidence=0.7,grayscale=True, region=simulation_window)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('seed.png'),confidence=0.7,grayscale=True, region=simulation_window)
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
        pyautogui.click(select, duration=0.25)
    if option=='current':
        try:
            select=pyautogui.locateCenterOnScreen(imPath('current_2.png'),confidence=0.7,grayscale=True, region=simulation_window)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('current.png'),confidence=0.7,region=simulation_window)
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
        pyautogui.click(select, duration=0.25)
    if option=='last':
        try:
            select=pyautogui.locateCenterOnScreen(imPath('last_2.png'),confidence=0.7,grayscale=True)
            pyautogui.click(select, duration=0.25)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('last.png'),confidence=0.7,region=simulation_window)
                pyautogui.click(select, duration=0.25)
            except pyautogui.ImageNotFoundException:
                try:
                  select=pyautogui.locateCenterOnScreen(imPath('current_2.png'),confidence=0.7,grayscale=True, region=simulation_window)
                  pyautogui.click(select, duration=0.25)
                  print('Used "current values" as seed values because "last steady state" option not available ')
                except pyautogui.ImageNotFoundException:
                    try:
                        select=pyautogui.locateCenterOnScreen(imPath('current.png'),confidence=0.7,region=simulation_window)
                        pyautogui.click(select, duration=0.25)
                        print('Used "current values" as seed values because "last steady state option" not available ')
                    except pyautogui.ImageNotFoundException:
                        pass
        
    if option=='complex':
        try:
            select=pyautogui.locateCenterOnScreen(imPath('seed_2.png'),confidence=0.7,grayscale=True,region=simulation_window)
            pyautogui.click(select, duration=0.25)
            time.sleep(1)
            select=pyautogui.locateCenterOnScreen(imPath('complex_2.png'),confidence=0.8,grayscale=True,region=simulation_window)
            pyautogui.click(select, duration=0.25)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('seed.png'),confidence=0.7,grayscale=True,region=simulation_window)
                pyautogui.click(select, duration=0.25)
                time.sleep(1)
                select=pyautogui.locateCenterOnScreen(imPath('complex.png'),confidence=0.8,grayscale=True,region=simulation_window)
                pyautogui.click(select, duration=0.25)
            except pyautogui.ImageNotFoundException:
                return 'Image not found' 

#6. Check which decimal separator is configured in the Windows Control Panel
import winreg

def get_decimal_separator():
    """
    Retrieves the decimal separator configured in the Windows Control Panel. BioWin uses the decimal separator configured in the Windows Control Panel.
    
    Returns:
    - The decimal separator configured in the Windows Control Panel if successful.
    - None if an error occurs during the retrieval process.
    """
    try:
        
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\International", 0, winreg.KEY_READ) # Open the registry key where the regional settings are stored
        
        decimal_separator, _ = winreg.QueryValueEx(key, "sDecimal") # Read the value of the decimal separator

        winreg.CloseKey(key) # Close the registry key

        return decimal_separator
    except Exception as e:
        print("Error while getting the decimal separator:", e)
        return None



#-----------------------------------------------

#7. Load influent data
def load_constant_influent(data): 
    """"
    Load constant influent data to the simulation.
    
    Args:
        - data (DataFrame): 1x12 each column corresponds to the influent parameter in the same order of appearance as in BioWin:
            column_names = ['Flow', 'COD (mg-COD/L)', 'TKN (mg-N/L)', 'TP (mg-P/L)', 'TS (mg-S/L)', 'Nitrate (mg-N/L)', 'pH', 'Alkalinity (mmol/L)', 'ISS total (mg-ISS/L)', 'Metal soluble - Ca (mg/L)', 'Metal soluble - Mg (mg/L)', 'Gas - Dissolved O2 (mg/L)']"
    
    Example:
        data=pd.DataFrame([[840,1040,32,37,10,0,5,6,45,80,15,0]],columns=column_names)
    """
    try:
        select=pyautogui.locateCenterOnScreen(imPath('infc_load_2.png'), confidence=0.7,grayscale=True)
        pyautogui.doubleClick(select)
        time.sleep(2)
        select=pyautogui.locateCenterOnScreen(imPath('constant_2.png'),confidence=0.8, grayscale=True, region=influent_window)
        pyautogui.click(select)
        time.sleep(1)
        select=pyautogui.locateCenterOnScreen(imPath('edit_2.png'), confidence=0.6,grayscale=True, region=influent_window)
        pyautogui.click(select)
        time.sleep(1)
        select=pyautogui.locateCenterOnScreen(imPath('infc_flow_2.png'),confidence=0.8,grayscale=True)
        pyautogui.click(select)
        time.sleep(1)
    except pyautogui.ImageNotFoundException:
        try:
            select=pyautogui.locateCenterOnScreen(imPath('infc_load.png'), confidence=0.7,grayscale=True)
            pyautogui.doubleClick(select)
            time.sleep(3)
            select=pyautogui.locateCenterOnScreen(imPath('constant.png'),confidence=0.8, grayscale=True, region=influent_window)
            pyautogui.click(select)
            time.sleep(1)
            select=pyautogui.locateCenterOnScreen(imPath('edit.png'), confidence=0.6,grayscale=True, region=influent_window)
            pyautogui.click(select)
            time.sleep(1)
            select=pyautogui.locateCenterOnScreen(imPath('infc_flow.png'),confidence=0.8,grayscale=True)
            pyautogui.click(select)
            time.sleep(1)
        except pyautogui.ImageNotFoundException:
            return 'Image not found'

    num_columns = data.shape[1]
    decimal_separator=get_decimal_separator()
    if decimal_separator == ',':
        for j in range(num_columns):
            value = data.iloc[0, j]
            formatted_value = str(value).replace('.', ',') 
            pyautogui.write(str(formatted_value), interval=0.05) 
            pyautogui.press('down')
    elif decimal_separator == '.':
        for j in range(num_columns):
            value = data.iloc[0, j]
            pyautogui.write(str(value), interval=0.05) 
            pyautogui.press('down')
    else: 
        print('Error while getting decimal separator')

    
    try:
        select=pyautogui.locateCenterOnScreen(imPath('inf_close_2.png'),confidence=0.8,grayscale=True)
    except pyautogui.ImageNotFoundException:
        try:
            select=pyautogui.locateCenterOnScreen(imPath('inf_close.png'),confidence=0.8,grayscale=True)
        except pyautogui.ImageNotFoundException:
            return 'Image not found'
    
    pyautogui.click(select)
    time.sleep(0.2)
    pyautogui.press('down')
    pyautogui.press('enter')


def load_variable_influent(data, name, filepath): 
    """
    Load variable influent data to the simulation. 
    Additionally, generates a .txt file to streamline influent data loading into BioWin.The .txt file is saved in the specified filepath. 
    The chosen filepath must be the same as the filepath selected in BioWin influent window. Choosing the same filepath where BioWin file is located is recommended. 
    
    Args:
        - data (DataFrame): DataFrame nx13.  
            - Each column corresponds to the influent's parameters in the same order of appearance as in BioWin: 
                column_names = ['Time','Flow', 'COD (mg-COD/L)', 'TKN (mg-N/L)', 'TP (mg-P/L)', 'TS (mg-S/L)', 'Nitrate (mg-N/L)', 'pH', 'Alkalinity (mmol/L)', 'ISS total (mg-ISS/L)', 'Metal soluble - Ca (mg/L)', 'Metal soluble - Mg (mg/L)', 'Gas - Dissolved O2 (mg/L)']"
            - Each row corresponds to the influent's parameters at the time specified in BioWin's time grid (minutes, days, hours).
        - name (str): name of the .txt file where the variable influent data will be saved. 
        - filepath (str): path where the generated .txt file with influent data will be saved. Use the form: r"path".
    
    Example:
        data = [[0,40,266,24,5.4,0,0,6,6,15,80,15,0],[1,100,246,35,5.4,0,0,6,6,15,80,15,0],[2,40,246,24,5.4,0,0,7.3,6,15,80,15,0],[4,200,246,35,5.4,0,0,6,6,15,80,15,0],[88,246,24,7,0,0,6,6,15,80,15,0]]
        data= pd.DataFrame(data, columns=column_names)
    """
    
    path = os.path.join(filepath, f'{name}.txt')
    decimal_separator=get_decimal_separator()
    if decimal_separator==',':
        data.to_csv(path,index=False,header=False, decimal=',', sep='\t')
    elif decimal_separator=='.':
        data.to_csv(path,index=False,header=False, sep='\t' )
    else:
        print("Error while getting the decimal separator")
    try:
        select=pyautogui.locateCenterOnScreen(imPath('infc_load_2.png'), confidence=0.7,grayscale=True)
        pyautogui.doubleClick(select)
        time.sleep(4)
        select=pyautogui.locateCenterOnScreen(imPath('variable_2.png'),confidence=0.8, grayscale=True, region=influent_window)
        pyautogui.click(select)
        time.sleep(1)
        select=pyautogui.locateCenterOnScreen(imPath('edit_2.png'), confidence=0.6,grayscale=True, region=influent_window)
        pyautogui.click(select)
        time.sleep(1)
        cycle_time=data.iloc[data.shape[0]-1,0]+1
        select=pyautogui.locateCenterOnScreen(imPath('cycle_time_2.png'),confidence=0.6,grayscale=True)
        pyautogui.click(select)
        start = time.time()
        while time.time() - start < 2:
            pyautogui.press('delete')
        time.sleep(1)
        pyautogui.write(str(cycle_time), interval=0.05)
        select=pyautogui.locateCenterOnScreen(imPath('load_infv_2.png'),confidence=0.7, grayscale=True)
        pyautogui.rightClick(select)
        time.sleep(0.5)
        for _ in range(7):
            pyautogui.press('down')
            time.sleep(0.0001)  
        pyautogui.press('enter')
        time.sleep(1)
        pyautogui.write(str(name),interval=0.05)
        pyautogui.press('enter')
        time.sleep(1)
        select=pyautogui.locateCenterOnScreen(imPath('load2_2.png'),confidence=0.7,grayscale=True)
        pyautogui.click(select)
        pyautogui.press('enter')
        
        time.sleep(2)
        select=pyautogui.locateCenterOnScreen(imPath('cycle_time_2.png'),confidence=0.6,grayscale=True,region=influent_window)
        pyautogui.click(select)
        time.sleep(0.5)

        select=pyautogui.locateCenterOnScreen(imPath('inf_close_2.png'),confidence=0.8,grayscale=True)
        pyautogui.click(select)
        time.sleep(0.5)
        pyautogui.press('down')
        pyautogui.press('enter')
    except pyautogui.ImageNotFoundException:
        try:
            select=pyautogui.locateCenterOnScreen(imPath('infc_load.png'), confidence=0.7,grayscale=True)
            pyautogui.doubleClick(select)
            time.sleep(4)
            select=pyautogui.locateCenterOnScreen(imPath('variable.png'),confidence=0.8, grayscale=True, region=influent_window)
            pyautogui.click(select)
            time.sleep(1)
            select=pyautogui.locateCenterOnScreen(imPath('edit.png'), confidence=0.6,grayscale=True, region=influent_window)
            pyautogui.click(select)
            time.sleep(1)
            cycle_time=data.iloc[data.shape[0]-1,0]+1
            select=pyautogui.locateCenterOnScreen(imPath('cycle_time.png'),confidence=0.6,grayscale=True)
            pyautogui.click(select)
            start = time.time()
            while time.time() - start < 2:
                pyautogui.press('delete')
            time.sleep(1)
            pyautogui.write(str(cycle_time), interval=0.05)
            select=pyautogui.locateCenterOnScreen(imPath('load_infv.png'),confidence=0.7, grayscale=True)
            pyautogui.rightClick(select)
            time.sleep(0.5)
            for _ in range(7):
                pyautogui.press('down')
                time.sleep(0.0001)  
            pyautogui.press('enter')
            time.sleep(1)
            pyautogui.write(str(name),interval=0.05)
            pyautogui.press('enter')
            time.sleep(1)
            select=pyautogui.locateCenterOnScreen(imPath('load2.png'),confidence=0.7,grayscale=True)
            pyautogui.click(select)
            pyautogui.press('enter')
            time.sleep(0.5)
            select=pyautogui.locateCenterOnScreen(imPath('inf_close.png'),confidence=0.8,grayscale=True)
            pyautogui.click(select)
            time.sleep(0.5)
            pyautogui.press('down')
            pyautogui.press('enter')
        except pyautogui.ImageNotFoundException:
            return 'Image not found'


#-----------------------------------------------

#8. Simulations
def steady_state(seed_mass, seed_SS,max_simulation_time):
    """
        Run a single steady state simulation in BioWin.
    
    Args: 
        - seed_mass (str): seed values for flow mass balance. Choose between the program's options: 'seed' (seed), 'current' (current values), 'last' (last steady state), 'complex' (complex seed). 'None' for not running flow balance.
        - seed_SS (str): seed values for steady state simulation. Choose between the program's options: 'seed' (seed), 'current' (current values), 'last' (last steady state), 'complex' (complex seed).
        - max_simulation_time (int): maximum time for finding the steady-state solution (in seconds). If the time for finding the solution exceeds the maximum time, simulation will stop. 
    """
    
    #Flow balance
    if seed_mass!='None':
        locate_biowin()
        time.sleep(0.5)
        pyautogui.press('f5')
        time.sleep(3)
        start_from(seed_mass)
        time.sleep(2) 
        pyautogui.press('enter')
        time.sleep(0.5)
        if check_cpu_usage('BioWin6.exe',1,120)==True: #max_time=60 sec, solving flow balance does not take much time.
            pyautogui.press('enter')
            logging.info('Flow balance') 
    
    #Steady state simulation
    time.sleep(2)
    locate_biowin()
    time.sleep(0.5)
    pyautogui.press('f6')
    time.sleep(1)
    try:
        select=pyautogui.locateCenterOnScreen(imPath('move2_2.png'),confidence=0.7,region=simulation_window,grayscale=True)
    except pyautogui.ImageNotFoundException:
        try:
            select=pyautogui.locateCenterOnScreen(imPath('move2.png'),confidence=0.7,region=simulation_window,grayscale=True)
        except pyautogui.ImageNotFoundException:
            return 'Image not found'
    pyautogui.click(select, duration=0.25)
    time.sleep(1)
    start_from(seed_SS)
    time.sleep(2) 
    pyautogui.press('enter')
    if check_cpu_usage('BioWin6.exe',1,max_simulation_time)==True: 
        pyautogui.press('enter')
        logging.info('Steady State')


def dynamic(start_conditions,days,max_simulation_time):
    """
    Run a single dynamic simulation in BioWin. 
    Args:
    - start_conditions (str): start conditions for the dynamic simulation. Choose between current values ('current') or last steady state values ('last').
    - days (int): length of the dynamic simulation in days. 
    - max_simulation_time (int): maximum time for running the dynamic simulation. If the time for finding the solution exceeds the maximum time, the simulation will stop. 
    """
    time.sleep(1)
    locate_biowin()
    time.sleep(0.5)
    pyautogui.press('f7')
    time.sleep(2)
    pyautogui.press('enter')
    time.sleep(1)
    try:
        select=pyautogui.locateCenterOnScreen(imPath('days_dynamic_2.png'),confidence=0.8, grayscale=True)
    except pyautogui.ImageNotFoundException:
        try:
            select=pyautogui.locateCenterOnScreen(imPath('days_dynamic.png'),confidence=0.8, grayscale=True)
        except pyautogui.ImageNotFoundException:
            return 'Image not found'
    pyautogui.click(select)
    start = time.time()
    while time.time() - start < 1:
        pyautogui.press('backspace')
    pyautogui.write(str(days),interval=0.05)
    time.sleep(0.5)
    if start_conditions=='current':
        try:
            select=pyautogui.locateCenterOnScreen(imPath('current_2.png'),confidence=0.8,grayscale=True)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('current.png'),confidence=0.8,grayscale=True)
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
    if start_conditions=='last':
        try:
            select=pyautogui.locateCenterOnScreen(imPath('last2_2.png'),confidence=0.8,grayscale=True)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('last.png'),confidence=0.8,grayscale=True)
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
        pyautogui.click(select, duration=0.25)
    
    pyautogui.press('enter')
    time.sleep(1)
    if check_cpu_usage('BioWin6.exe',1,max_simulation_time)==True: 
        try:
            select=pyautogui.locateCenterOnScreen(imPath('stop_2.png'),grayscale=True, region=simulation_window)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('stop.png'),grayscale=True, region=simulation_window)
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
        pyautogui.click(select)
        time.sleep(0.5)
        pyautogui.press('enter')
        logging.info('Dynamic simulation')


#-----------------------------------------------
#9. Save results
def save_results(option,simulation_name,scenario,filepath=None):
    """
    Save simulation results. 
    
    Args:
        - options (str): 'table' (csv file with PAGE 1 ALBUM DATA, a table with the data of interest must be created on the page 1 of the album) or 'report' (Excel report generated by BioWin).
        - simulation_name (str): name for the generated file. 
        - scenario (int): scenario number. To keep track of which scenario the results are from (e.g., 1).
        - filepath (optional): only required if 'table' option is used. Specifies the filepath where to save the .csv file. For the option 'report', the excel report generated by BioWin will be saved in the specified filepath in BioWin (File->Report to Excel->File path). 
    """ 
    if option=='table':
        time.sleep(1)
        try:
            select=pyautogui.locateCenterOnScreen(imPath('exp_album_2.png'),confidence=0.8)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('exp_album.png'),confidence=0.8)
            except:
                return 'Image not found'
        pyautogui.click(select)
        time.sleep(2)
        try: 
            select=pyautogui.locateCenterOnScreen(imPath('biowin_album_2.png'),confidence=0.8)
            pyautogui.rightClick(select)
            time.sleep(0.5)
            pyautogui.press('down')
            pyautogui.press('down')
            pyautogui.press('down')
            pyautogui.press('down')
            pyautogui.press('down')
            pyautogui.press('enter')
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('biowin_album.png'),confidence=0.8, grayscale=True)
                pyautogui.rightClick(select)
                time.sleep(0.5)
                pyautogui.press('down')
                pyautogui.press('down')
                pyautogui.press('down')
                pyautogui.press('down')
                pyautogui.press('down')
                pyautogui.press('enter')
            except pyautogui.ImageNotFoundException:
                pass
        time.sleep(0.5)
        pyautogui.moveTo(800, 800)
        pyautogui.rightClick()
        time.sleep(0.5)
        pyautogui.press('down')
        pyautogui.press('down')
        pyautogui.press('enter')
        simulation_results=pd.read_clipboard()
        time.sleep(1)
        try:
            select=pyautogui.locateCenterOnScreen(imPath('exp_close_album_2.png'),confidence=0.7)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('exp_close_album.png'),confidence=0.7) 
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
        pyautogui.click(select)
        simulation_results.iloc[:, 1:] = simulation_results.iloc[:, 1:].apply(lambda x: x.astype(str).str.replace(',', '.')).apply(pd.to_numeric, errors='coerce')
        name = f'{simulation_name}_{scenario}.csv'
        file = os.path.join(filepath, name)
        simulation_results.to_csv(file,index=False)
    if option=='report':
        try:
            select=pyautogui.locateCenterOnScreen(imPath('exp_file_2.png'),confidence=0.7)
        except pyautogui.ImageNotFoundException:
            try:
                select=pyautogui.locateCenterOnScreen(imPath('exp_file.png'),confidence=0.7)
            except pyautogui.ImageNotFoundException:
                return 'Image not found'
        pyautogui.click(select)
        time.sleep(1)
        pyautogui.press('down')
        pyautogui.press('down')
        pyautogui.press('down')
        pyautogui.press('down')
        pyautogui.press('down')
        pyautogui.press('down')
        pyautogui.press('down')
        pyautogui.press('down')
        pyautogui.press('enter')
        time.sleep(3)
        name=f'{simulation_name}_{scenario}'
        pyautogui.write(str(name), interval=0.05)
        pyautogui.press('enter')
        if check_cpu_usage('BioWin6.exe',10,120)==True: 
            pyautogui.press('esc')

#-----------------------------------------------

#STEADY STATE SIMULATIONS
def steady_state_simulations(influent_type, influent,seed_mass,seed_SS,max_simulation_time, result_type,filepath=None):
    """
    The 'steady_state_simulations' function allows the user to run multiple steady state simulations for constant or variable influent. 
    It has the option of running a flow balance before running the steady state simulation, a good practice when working with complex systems. 
    Args:
    - influent_type (str): Specify whether the influent is constant ('constant') or variable ('variable') over time.
    - influent:
        - If the influent type is constant (DataFrame): 
            Each row corresponds to different influent scenarios to be tested. Columns represent influent characteristics in the same order as in BioWin: ['Flow', 'COD (mg-COD/L)', 'TKN (mg-N/L)', 'TP (mg-P/L)', 'TS (mg-S/L)', 'Nitrate (mg-N/L)', 'pH', 'Alkalinity (mmol/L)', 'ISS total (mg-ISS/L)', 'Metal soluble - Ca (mg/L)', 'Metal soluble - Mg (mg/L)', 'Gas - Dissolved O2 (mg/L)']
        - If the influent type is variable (Dictionary):
            Each Dictionary key corresponds to a different scenario. 
                - Each Dictionary key column corresponds to the influent's parameters in the same order of appearance in BioWin: column_names = ['Time','Flow', 'COD (mg-COD/L)', 'TKN (mg-N/L)', 'TP (mg-P/L)', 'TS (mg-S/L)', 'Nitrate (mg-N/L)', 'pH', 'Alkalinity (mmol/L)', 'ISS total (mg-ISS/L)', 'Metal soluble - Ca (mg/L)', 'Metal soluble - Mg (mg/L)', 'Gas - Dissolved O2 (mg/L)']. 
                - Each Dictionary key row corresponds to the influent's parameters at the time specified in the time grid (minutes, days, hours).
                - Dictionary entries should be ordered from the one with the least number of rows to the one with the most.
    - seed_mass (str): seed value for flow mass balance. Choose between the program options: 'seed' (seed), 'current' (current values), 'last' (last steady state), 'complex' (complex seed). 'None' for not running flow balance. 
    - seed_SS (str): seed value for the steady state simulations. Choose between the program options: 'seed' (seed), 'current' (current values), 'last' (last steady state), 'complex' (complex seed).
    - max_simulation_time (int): sets the maximum time (in seconds) for finding the steady-state solution of each scenario. If the time for finding the solution exceeds the maximum time, the simulation will stop.  
    - result_type (str): 'table' (csv file with album results, file will be saved in the filepath specified on the arg 'filepatch'), 'report' (excel report generated by BioWin, report will be saved on the specified filepath in BioWin) , 'complete' (csv file and excel report) ,'none' (does not save simulation results). 
    - filepath: specifies where the generated files are saved, use de form r"filepath". 
        For simulations with constant influent, and result type 'table': filepath for saving csv file. 
        For simulations with constant influent, and result type 'report': filepath does not has to be specified. The excel report generated by BioWin will be saved in the specified filepath in BioWin (File->Report to Excel->File path). 
        For simulations with variable influent: a .txt file is generated by the function to ease influent data loading in BioWin.  Filepath specifies where to save the .txt file with influent data. The chosen filepath must be the same as the filepath selected in BioWin influent window to load the data. Choosing the same filepath where BioWin file is located is recommended. 
    
    Returns:
    Excel report generated by the program or a CSV file with results specified on the first page of the BioWin album.
    """
    time.sleep(0.5)
    maximize()
    time.sleep(2)
    if influent_type=='constant':
       scenarios=influent.shape[0] #rows
       for i in range(scenarios):
        scenario_data=pd.DataFrame(influent.iloc[i]).T
        #Load influent data
        load_constant_influent(scenario_data)
        #Run steady state simulation
        steady_state(seed_mass, seed_SS,max_simulation_time)
        #Save results
        if result_type=='table':
            save_results(result_type,'steady_state_c',i,filepath)
            time.sleep(2)
        if result_type=='report':
            save_results(result_type,'steady_state_c',i)
            time.sleep(2)
        if result_type=='complete':
            save_results('report','steady_state_c',i)
            time.sleep(1)
            save_results('table','steady_state_c',i,filepath)
            time.sleep(2)
        if result_type=='None':
            time.sleep(0.1)

    if influent_type=='variable':
        for key in influent:
            data_sim=influent[key]
            name=f'{key}'
            #Load influent data
            load_variable_influent(data_sim,name,filepath)
            #Run steady state simulation
            steady_state(seed_mass, seed_SS,max_simulation_time)
            #Save results
            if result_type=='table':
                save_results(result_type,'steady_state_v',key, filepath)
                time.sleep(2)
            if result_type=='report':
                save_results(result_type,'steady_state_v',key)
                time.sleep(2)
            if result_type=='complete':
                save_results('report','steady_state_v',key)
                time.sleep(1)
                save_results('table','steady_state_v',key,filepath)
                time.sleep(2)
            if result_type=='None':
                time.sleep(0.1)
    time.sleep(4)
    minimize()
    time.sleep(2)
#-----------------------------------------------

#DYNAMIC SIMULATIONS
def dynamic_simulations(influent_type, influent,start_conditions,days,max_simulation_time,filepath=None):    
    """
    The 'dynamic_simulations' function allows the user to run multiple dynamic simulations for a constant or variable influent. 


    Args:
    - influent_type (str): Specify whether the influent is constant ('constant') or variable ('variable') over time.
    - influent:
        - If the influent type is constant (DataFrame): 
            Each row corresponds to different scenarios to be tested. Columns represent influent characteristics in the same order as in BioWin.['Flow', 'COD (mg-COD/L)', 'TKN (mg-N/L)', 'TP (mg-P/L)', 'TS (mg-S/L)', 'Nitrate (mg-N/L)', 'pH', 'Alkalinity (mmol/L)', 'ISS total (mg-ISS/L)', 'Metal soluble - Ca (mg/L)', 'Metal soluble - Mg (mg/L)', 'Gas - Dissolved O2 (mg/L)'].
        - If the influent type is variable (Dictionary):
            Each Dictionary key corresponds to a different scenario. 
                - Each Dictionary key column corresponds to the influent's parameters in the same order of appearance in BioWin: column_names = ['Time','Flow', 'COD (mg-COD/L)', 'TKN (mg-N/L)', 'TP (mg-P/L)', 'TS (mg-S/L)', 'Nitrate (mg-N/L)', 'pH', 'Alkalinity (mmol/L)', 'ISS total (mg-ISS/L)', 'Metal soluble - Ca (mg/L)', 'Metal soluble - Mg (mg/L)', 'Gas - Dissolved O2 (mg/L)']. 
                - Each Dictionary key row corresponds to the influent's parameters at the time specified in the time grid (minutes, days, hours).
                - Dictionary entries should be ordered from the one with the least number of rows to the one with the most.
    - start_conditions (str): start conditions for the dynamic simulation. Choose between current values ('current') or last steady state values ('last').
    - days (int): length of the dynamic simulation in days. 
    - max_simulation_time (int): sets the maximum time for running the dynamic simulation. If the time for finding the solution exceeds the maximum time, the simulation will stop. 
    - filepath (optional): only if influent_type='variable'. When working with variable influen data .txt files are generated for loading influent data to BioWin. Filepath specifies where the .txt files are saved. The chosen filepath must be the same as the filepath selected in BioWin influent window to load the data. Choosing the same filepath where BioWin file is located is recommended. 
    
    Returns:
    Excel report generated by the program or a CSV file with results specified on the first page of the BioWin album.
    
    Returns:
    Excel report generated by BioWin.
    """
    time.sleep(0.5)
    maximize()
    time.sleep(2)
    if influent_type=='constant':
       scenarios=influent.shape[0] #rows
       for i in range(scenarios):
        scenario_data=pd.DataFrame(influent.iloc[i]).T
        #Load influent data
        load_constant_influent(scenario_data)
        #Run dynamic simulation
        time.sleep(2)
        dynamic(start_conditions,days,max_simulation_time)
        #Save results
        time.sleep(1)
        save_results('report','dynamic_c',i)

    if influent_type=='variable':
        for key in influent:
            data_sim=influent[key]
            name=f'{key}'
            #Load influent data
            load_variable_influent(data_sim,name,filepath)
            time.sleep(1)
            #Run steady state simulation
            dynamic(start_conditions,days,max_simulation_time)
            #Save results
            time.sleep(1)
            save_results('report','dynamic_v',key)
            time.sleep(3)
    
    time.sleep(4)
    minimize()
    time.sleep(2)

#-----------------------------------------------



